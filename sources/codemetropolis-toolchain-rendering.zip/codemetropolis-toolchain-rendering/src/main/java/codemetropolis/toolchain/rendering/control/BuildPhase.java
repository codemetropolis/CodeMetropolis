package codemetropolis.toolchain.rendering.control;

public enum BuildPhase {
	READING_INPUT_FILE,
	GENERATING_BLOCKS,
	PLACING_BLOCKS
}
