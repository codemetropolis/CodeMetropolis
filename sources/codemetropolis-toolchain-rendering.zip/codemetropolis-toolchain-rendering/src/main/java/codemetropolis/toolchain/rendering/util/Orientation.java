package codemetropolis.toolchain.rendering.util;

public enum Orientation {
	NearX,
	NearY,
	NearZ,
	FarX,
	FarY,
	FarZ
}
